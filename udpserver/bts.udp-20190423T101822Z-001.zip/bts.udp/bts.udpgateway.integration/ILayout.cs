﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bts.udpgateway.integration
{
    public interface ILayout
    {
        void dump(string content);
    }
}
