﻿using knote.utils;
using MySql.Data.MySqlClient;
using RestSharp;
using RestSharp.Deserializers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace bts.udpgateway.integration
{
    static public class Integrator
    {
        static public ReturnInfo Insert(string msg_content)
        {
            try
            {
                XtraLog.Write("[INSERT:BEGIN] Insert message content into database", LogLevel.INFO, "Integrator.Insert");
                MySqlConnection dbConnection = new MySqlConnection();
                dbConnection.ConnectionString = ConfigHelper.ConnectionString;
                //dbConnection.Open();
                MySqlCommand command = dbConnection.CreateCommand();
                command.CommandText = "insert into messages(message) values(@message)";
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@message", msg_content);
                XtraLog.Write(string.Format("[INSERT:CONTENT]\r\n{0}\r\n", msg_content), LogLevel.INFO, "Integrator.Insert");
                if (dbConnection.State != System.Data.ConnectionState.Open)
                    dbConnection.Open();
                int count = command.ExecuteNonQuery();
                return new ReturnInfo(ReturnCode.Success);
            }
            catch (Exception ex)
            {
                XtraLog.Write(string.Format("[INSERT:EXCEPTION]\r\n{0} : {1}\r\n[TRACE]:\r\n{2}", ex.GetType(), ex.Message, ex.StackTrace), LogLevel.EXCEPTION, "Integrator.Insert");
                return new ReturnInfo(data: ex);
            }
            finally
            {
                XtraLog.Write("[INSERT:END] Insert message content into database", LogLevel.INFO, "Integrator.Insert");
            }
        }
        static public ReturnInfo GetPendingMessages()
        {
            try
            {
                XtraLog.Write("[GET:BEGIN] Get pending message from web-api", LogLevel.INFO, "Integrator.GetPendingMessages");
                RestClient client = new RestClient(ConfigHelper.WapiBaseUrl);
                RestRequest request = new RestRequest(ConfigHelper.WapiGetPending, Method.GET);
                IRestResponse response = client.Execute(request);
                if (response == null)
                    return new ReturnInfo(ReturnCode.Error, string.Format("[GET:RESULT] Cannot get response from web-api ({0})", ConfigHelper.WapiGetPending));

                List<Message> list = new JsonDeserializer().Deserialize<List<Message>>(response);
                if (list == null)
                    list = new List<Message>();
                return new ReturnInfo(data: list);
            }
            catch (Exception ex)
            {
                XtraLog.Write(string.Format("[GET:EXCEPTION]\r\n{0} : {1}\r\n[TRACE]:\r\n{2}", ex.GetType(), ex.Message, ex.StackTrace), LogLevel.EXCEPTION, "Integrator.GetPendingMessages");
                return new ReturnInfo(data: ex);
            }
            finally
            {
                XtraLog.Write("[GET:END] Get pending message from web-api", LogLevel.INFO, "Integrator.GetPendingMessages");
            }
        }
        static public ReturnInfo UpdatePendingMessage(int message_id)
        {
            try
            {
                XtraLog.Write("[UPDATE:BEGIN] Update pending message via web-api", LogLevel.INFO, "Integrator.UpdatePendingMessage");
                RestClient client = new RestClient(ConfigHelper.WapiBaseUrl);
                string request_url = string.Format("{0}/{1}", ConfigHelper.WapiUpdateDone, message_id);
                RestRequest request = new RestRequest(request_url, Method.GET);
                IRestResponse response = client.Execute(request);
                if (response == null)
                    return new ReturnInfo(ReturnCode.Error, string.Format("[UPDATE:RESULT] Cannot get response from web-api ({0})", ConfigHelper.WapiGetPending));

                /*
                 * not know response format of update api
                 */
                //List<Message> list = new JsonDeserializer().Deserialize<List<Message>>(response);
                //if (list == null)
                //    list = new List<Message>();

                return new ReturnInfo(ReturnCode.Success);
            }
            catch (Exception ex)
            {
                XtraLog.Write(string.Format("[UPDATE:EXCEPTION]\r\n{0} : {1}\r\n[TRACE]:\r\n{2}", ex.GetType(), ex.Message, ex.StackTrace), LogLevel.EXCEPTION, "Integrator.UpdatePendingMessage");
                return new ReturnInfo(data: ex);
            }
            finally
            {
                XtraLog.Write("[UPDATE:END] Update pending message from web-api", LogLevel.INFO, "Integrator.UpdatePendingMessage");
            }
        }
    }
}
